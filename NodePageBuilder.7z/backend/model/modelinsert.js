let page = [
        {
            name: 'Section Biru',
            html: '<div style="background-color: #3b82f6; width: 100%; height: 400px; display: flex; align-items: center; justify-content: center; color: white; font-family: sans-serif; font-size: 2rem;">Section 1</div>',
            image: 'https://placehold.co/300x150/3b82f6/ffffff?text=Section+Biru'
        },
        {
            name: 'Section Hijau',
            html: '<div style="background-color: #10b981; width: 100%; height: 400px; display: flex; align-items: center; justify-content: center; color: white; font-family: sans-serif; font-size: 2rem;">Section 2</div>',
            image: 'https://placehold.co/300x150/10b981/ffffff?text=Section+Hijau'
        },
        {
            name: 'Section Abu-abu',
            html: '<div style="background-color: #6b7280; width: 100%; height: 400px; display: flex; align-items: center; justify-content: center; color: white; font-family: sans-serif; font-size: 2rem;">Section 3</div>',
            image: 'https://placehold.co/300x150/6b7280/ffffff?text=Section+Abu-abu'
        },
        {
            name: 'Section Ungu',
            html: '<div style="background-color: #8b5cf6; width: 100%; height: 400px; display: flex; align-items: center; justify-content: center; color: white; font-family: sans-serif; font-size: 2rem;">Section 4</div>',
            image: 'https://placehold.co/300x150/8b5cf6/ffffff?text=Section+Ungu'
        }
];

export default page;