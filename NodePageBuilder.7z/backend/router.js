import express from 'express';
import pages from './model/pagemodel.js';

const router = express.Router();

const getPages = async(req, res)=>{
    try {
        const section = await pages.findAll();
        res.json(section);
    } catch (error) {
        console.error(error);
    }
}

router.get('/section',getPages);

export default router;