import express from "express";
import db from "./config/database.js";
//import page from "./model/modelinsert.js";
//import pages from "./model/pagemodel.js";
const app = express();

try {
    await db.authenticate();
    console.log("Database berhasil terknoneksi!");
    //await pages.bulkCreate(page);
} catch (error) {
    console.error(error);
    
}
app.listen(5000, ()=>console.log("Server berjalan pada port 5000"));