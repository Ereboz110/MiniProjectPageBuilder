import { Sequelize } from "sequelize";

const db = new Sequelize('pagebuilder', 'root', '',{
    host: 'localhost',
    dialect: 'mysql'
})

export default db