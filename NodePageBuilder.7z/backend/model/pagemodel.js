import {Sequelize} from "sequelize";
import db from "../config/database.js";

const {DataTypes} = Sequelize;

const pages = db.define('page',{
        name:{
            type: DataTypes.STRING(255)
        },
        html:{
            type: DataTypes.TEXT('long')
        },
        image:{
            type: DataTypes.TEXT
        }
    },

    {
        freezeTableName:true
});

export default pages;