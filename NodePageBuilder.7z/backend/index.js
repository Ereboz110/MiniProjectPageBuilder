import express from "express";
import db from "./config/database.js";
//import page from "./model/modelinsert.js";
//import pages from "./model/pagemodel.js";
import router from './router.js';
import cors from 'cors'

const app = express();
app.use(cors())
app.use(router);


try {
    await db.authenticate();
    console.log("Database berhasil terknoneksi!");
    //await page.sync;
    //await pages.bulkCreate(page);
} catch (error) {
    console.error(error);
    
}



app.listen(5000, ()=>console.log("Server berjalan pada port 5000"));