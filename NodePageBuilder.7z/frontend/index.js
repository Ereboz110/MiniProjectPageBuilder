let canvas = [];

fetch('http://localhost:5000/section')
.then(res => res.json())
.then(data=>{
    console.log(data);
    const sidebar = document.getElementById('sidebar');

    data.forEach(section =>{
        const list = document.createElement('li');
        list.className = 'nav-item list-unstyled';

        const match = section.html.match(/background-color:\s*(#[0-9a-fA-F]{6})/);
        let warna = '#3b82f6';  
        if (match) {
        warna = match[1];   
            }

        const button = document.createElement('button');
        button.className = 'btn py-5 my-2 w-100 rounded-0';
        button.style.backgroundColor = warna;
        button.style.color = 'white';

        button.onclick = ()=>{
            const wrapper = document.createElement('div');
            wrapper.className = 'section-wrapper d-flex justify-content-center';

            const img = document.createElement('img');
            img.style.width = '80%';
            img.style.maxWidth = '1200px';
            img.style.margin = '0 auto'
            img.src = section.image;
            img.className = 'img-fluid';
            wrapper.appendChild(img);
            document.getElementById('canvas').appendChild(wrapper);

            canvas.push(section.html);
        };

        list.appendChild(button);
        sidebar.appendChild(list);
    });
})

document.getElementById('download-button').onclick = () =>{
    const htmlcode = `
    <!DOCTYPE html>
    <html>
    <head></head>
    <body>
        ${canvas.join('\n')}
    </body>
    </html>`;

    const blob = new Blob([htmlcode],{
        type: 'text/html'
    });
    const url = document.createElement('a');
    url.href = URL.createObjectURL(blob);
    url.download = 'html-page';
    url.click();
};